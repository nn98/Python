"""
입력하는 문장의 단어의 개수를 출력하시오. 대소문자 구별을 하지 않게 처리하라.
“'.,!?()/ 는 단어가 아니다.

입력예)
문장: While The Python Language Reference describes the exact syntax and semantics of the Python language, this library
reference manual describes the standard library that is distributed with Python.
It also describes some of the optional components that are commonly included in Python distributions.

출력예)

단어의 개수:
"""
words = input("입력:")
#문장 입력
splitwords = words.split()
#문장을 공백 기준으로 잘라서 저장.

wordset = set()
#단어를 저장할 빈 세트를 생성.

for word in splitwords: #공백 기준으로 자른 단어에 특수문자가 있는지 확인해야함.
    result = ""#특수문자 지운 단어를 임시로 저장할 변수
    for i in word:#단어를 철자 기준으로 다시 자름
        if i.isalpha() == True:#철자가 알파벳이면
            result += i #result에 저장
    wordset.add(result.lower())#result에 저장된 특수문자 지운 단어를 소문자로 바꾸어 set에 저장.

print("단어의 개수 :", len(wordset))