"""
작성자:IT융합자율학부 201914141 임윤휘
lab7_4
입력하는 문장의 단어의 개수를 출력하시오. 대소문자 구별을 하지 않게 처리하라. “'.,!?()/ 는 단어가 아니다.
입력예)
문장: While The Python Language Reference describes the exact syntax and semantics of the Python language,
 this library reference manual describes the standard library that is distributed with Python.
 It also describes some of the optional components that are commonly included in Python distributions.
 출력예)
단어의 개수:
"""
user=input("문장:").lower()  #대소문자 구분 안 함

#if in 시퀀스를 이용해서 문자열인 상태에서 “'.,!?()/가 아닌 요소들을 구하여 새 문자열을 만든다.
rem=["\"", "\'", ".", ",", "(", ")", "!", "?", "/"]  #단어 수 계산에서 제외될 문자들
re_user=""   #단어가 아닌 문자들을 제외한 문자들을 저장할 빈 문자열

for i in user:    #입력받은 문자열의 각 요소들 i에 저장하며 반복
    if i not in rem:  #i가 rem 시퀀스에 있지 않을 경우 True
        re_user+=i   #문자열은 + 연산자로 문자열끼리 합칠 수 있다.
"""
단어가 아닌 문자를 제외한 새 문자열을 split()를 이용하여 단어별로(띄어쓰기별로) 나누고
세트로 형변환하여 중복되는 단어를 삭제
"""
result=set(re_user.split())

print("단어의 개수:", len(result))