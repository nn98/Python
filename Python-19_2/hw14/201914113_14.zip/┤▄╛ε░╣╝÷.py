"""
입력하는 문장의 단어의 개수를 출력하시오. 대소문자 구별을 하지 않게 처리하라.
“'.,!?()/ 는 단어가 아니다.
"""
def process(w):
    """
    단어에서 구두점을 제거하고 대문자를 소문자로 바꿔주는 함수
    :param w:
    :return: 소문자를 출력
    """
    output = "" #저장을 하기 위해서 만듬
    for ch in w:
        if(ch.isalpha()): #알파벳이면
            output += ch  #output에 추가
    return output.lower()  #알파벳을 소문자로 변화시킴
words = set() #공백세트 생성
fname = input("문장:").split() #받은 문장을 나눠서 fname에 저장

for line in fname: #fname에 있는 모든 줄 반복하게 만듬
    linewords = line.split()  #line에 있는걸 쪼개서 linewords에 저장
    for word in linewords: #linewords에 있는것 만큼 반복
        words.add(process(word)) #현재 공백인 Word에 lineword에 있는것을 계속 추가

print("단어의 개수:",len(words)) #단어의 개수 출력
"""
data = ""

file = open("C:\\temp\\data.txt","r",encoding='UTF8')
for line in file.readlines():
    data.append(line.strip())
"""