"""
문제: 입력하는 문장의 단어의 개수를 출력하시오.
"'.,!?()/ 는 단어가 아니다.
입력예)
문장: While The Python Language Reference describes the exact syntax and semantics of the Python language, this library reference manual describes the standard library that is distributed with Python. It also describes some of the optional components that are commonly included in Python distributions.
출력예)
단어의 개수:

작성자: 유수빈
작성일: 2019-11-07
"""

s=input('문장:') # 입력받기(split=문자열 공백만큼 구분해서 나누기)

# 단어가 아닌 문장부호를 삭제하기
s=s.replace(',',' ')
s=s.replace('.',' ')
s=s.replace('!',' ')
s=s.replace('?',' ')
s=s.replace('(',' ')
s=s.replace(')', ' ')
s=s.replace('/',' ')
s=s.replace("'", ' ')
s=s.replace('"', ' ')

word_count=[] # 빈 리스트 작성
l=s.lower() #s(입력한 문자열)를 모두 소문자로 변환 -> 이유는 해결하기 어려웠던 점에 있음
words=l.split() # 소문자로 변환한 것을 공백으로 나누기 ! -> while the => 'while' 'the'로 분류됨



#반복(코드를 필요한 만큼 반복 실행)
for word in words:
    word_count.append(word) #word_count 리스트에 word를 추가

count=set(words) # count 라는 변수에 단어의 중복 제거를 저장

print() #한 줄 띄우기
print('단어의 개수:', len(count)) # 단어의 개수 출력
print(count) #어떤 단어들로 분류되었는지 출력 -> 단어 확인 가능