"""입력하는 문장의 단어의 개수 출력
대소문자 구별 하지 않게 처리
"'.,?!()/는 단어 아님"""
"""작성자: 이자영
작성일:191111"""
"""입력 예)While The Python Language Reference describes the exact syntax and semantics of the Python language, this library reference manual describes the standard library that is distributed with Python.It also describes some of the optional components that are commonly included in Python distributions.
출력) 개수:
 
 """
#단어에서 구두점 제거하고 소문자로 만든다
def process(w):
    output=''
    for ch in w:
        if( ch.isalpha() ):
                   output += ch
    return output.lower()
words=set()#공백 세트 생성

fname = input("문장을 쓰세요: ")#문장 입력받기

linewords = fname.split()
for word in linewords:
    words.add(process(word))#단어에 세트 추가
print("단어의 개수: ",len(words))#출력 받기