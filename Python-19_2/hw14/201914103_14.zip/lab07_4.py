"""
입력하는 문장의 단어의 개수를 출력하시오.
"'.,!?()/는 단어가 아니다.
입력 예)
문장:While The Python Language Reference describes the exact syntax and semantics of the Python language,
this library reference manual describes the standard library that is distributed with Python.
It also describes some of the optional components that are commonly included in Python distributions.
출력 예)
단어의 개수:

작성자:이지선
작성일:2019.11.10
"""
str = input("문장: ").upper() #소문자를 대문자로 변환
#replace()를 사용해 특수기호를 제거
str = str.replace('"','')
str = str.replace('\'','')
str = str.replace('.','')
str = str.replace(',','')
str = str.replace('!','')
str = str.replace('?','')
str = str.replace('(','')
str = str.replace(')','')
str = str.replace('/','')

str = set(str.split())  #split()으로 문자열을 나누고 set()으로 변환하여 중복 제거

sum = 0 #합 초기화

for i in str:
    if i.isalpha():  # 문자열이 알파벳으로만 구성되어 있으면 True 반환
        sum += 1

print("단어의 개수:", sum)  #출력
