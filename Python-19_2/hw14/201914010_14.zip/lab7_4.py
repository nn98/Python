def process(s): # process 함수 정의
    output = ""
    for ch in s:
        if ch.isalpha(): # isalpha 문자인지 확인
            output = output + ch
    return output.lower() # 소문자로 바꾼 후 반환

string = input().split() # 입력 받기
linewords = string # 입력 받은 문장 linewords에 저장
for i in range(len(linewords)):
    linewords[i] = process(linewords[i]) # linewords의 인덱스를 함수에 대입
linewords = set(linewords) # linewords의 단어 중복 제거
print("단어의 개수: ", len(linewords)) # 출력