"""
입력하는 문장의 단어의 개수 출력하시오. 대소문자 구별을 하지 않게 처리하라.
" ' . , ! ? ( ) / 는 단어가 아니다.
입력예)
문장:while the python language,,,,
출력예)
단어의 개수:
"""
s=set(input("문장:").strip('\'\".,!?()\\').lower().split())
sum=0
for x in s:
    if x.isalpha():
        sum+=1

print("단어의 개수:",sum)
