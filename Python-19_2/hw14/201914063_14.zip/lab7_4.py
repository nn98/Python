"""
입력하는 문장의 단어의 개수를 출력하시오. 대소문자 구별을 하지 않게 처리하라.
“'.,!?()/ 는 단어가 아니다.
"""
def process(w):     # 단어가 아닌 문자를 제거하고, 사용자가 입력한 문자를 소문자로 바꾸는 함수
    output = ""
    for ch in w:            # 매개변수(w)의 ch(문자)에 대해서 반복 실행
        if(ch.isalpha()):   # ch(문자)가 알바펫이면 output에 ch를 추가
                output += ch
    return output.lower() # output의 값을 소문자로 바꿔서 return 함

words = set() # 공백인 set() words를 만든다.

user = input() # 사용자에게 입력 받을 문장 저장하는 변수 user

allwords = user.split() # user를 공백을 기준으로 나눈 리스트를 저장할 변수 allwords
for word in allwords:
    words.add(process(word)) # words에 process(word)를 추가, words는 set()형식이므로 자동으로 중복된 요소 제거

print("단어의 개수: ", len(words))   # words의 길이 출력
