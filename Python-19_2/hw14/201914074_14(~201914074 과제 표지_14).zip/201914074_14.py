"""
작성자:나현호
작성일19.11.11
"""
a = input("문장:").split()#입력받은 문장을 띄어쓰기 단위로 자른다.
for i in range(len(a)):#대소문자 구분 없기 때문에 모두 대문자로 만들어 비교한다
    a[i]= a[i].upper()
for i in range(len(a)):
    for j in range(len(a[i])): #만약 문자열안에 특수문자가 있다면 특수문자를 삭제한다.
        a[i] = list(a[i])
        if a[i][-1]== "," or a[i][-1]== "." or a[i][-1]== "/" or a[i][-1]== "!" or a[i][-1]== "?" or a[i][-1]== "(" or a[i][-1]== ")" or a[i][-1]== "'" or a[i][-1]== '"':
            a[i].pop()
        elif a[i][0] == '"':
            a[i].remove('"')
        elif a[i][0] == "'":
            a[i].remove("'")
        a[i] = ''.join(a[i])
a = set(a)#리스트를 집합으로 바꾼다. 집합의 특성상 동일한 문자열은 삭제된다.
print("단어의 갯수:",len(a))

