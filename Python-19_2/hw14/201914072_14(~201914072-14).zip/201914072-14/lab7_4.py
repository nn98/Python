"""
입력하는 문장의 단어의 개수를 출력하시오. 대소문자 구별을 하지 않게 처리하라.
".,!?()/ 는 단어가 아니다
"""

s=list(input("문장:"))                      #문장 입력
ss=""                                       #나중에 다시 다 합치기 위해 만들어두기
remove_list=['.',',','?','!','"','\'']      #없앨 것들

for i in range(len(remove_list)):           #단어가 아닌것들을 없애기
    while remove_list[i] in s:              #만약 없앨 것이 입력받은 문장에 있다면
        s.remove(remove_list[i])            #그거 없애기

for i in range(len(s)):                     #대문자를 모두 소문자로 바꾸어 구분없게 만들기
    if ord(s[i]) >= 65 and ord(s[i]) <= 90:     #대문자면
        s[i] = chr(ord(s[i]) + 32)              #소문자로 바꾸기

for i in range(len(s)):                     #다시 다 합치기
    ss+=s[i]

word=set(ss.split())                        #중복 단어 하나로

print("단어의 개수:",len(word))              #단어 개수
