#문자열 입력
sentence = input("문장 : ")

# 문장부호 제거
for change in '"'+"'.,!?()/" :
    sentence = sentence.replace(change, "") #change에 문장부호가 있으면 공백으로 대체하라

# 소문자로 변경
sentence = sentence.lower() #str타입을 소문자로 변경하라

# 단어를 set으로 처리
sentset = set(sentence.split(' ')) #공백으로 나눈 후 set에 저장, 중복은 파기
print("단어의 개수 : ",len(sentset))