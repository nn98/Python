"""
과제번호: 14
학번: 201535038
성명: 최현민
학과: 컴퓨터공학과
학년: 3
제출일: 2019. 11. 11

문제)
입력하는 문장의 단어의 개수를 출력하시오. 대소문자 구별을 하지 않게 처리하라.
“'.,!?()/ 는 단어가 아니다.
입력예)
문장: While The Python Language Reference describes the exact syntax and semantics of the Python language, this library reference manual describes the standard library that is distributed with Python. It also describes some of the optional components that are commonly included in Python distributions.
출력예)
단어의 개수:
"""
import string
l = input("문장: ").lower().split() # 입력받은 문장을 소문자로 바꾸고, 공백을 기준으로 분리하여 리스트에 저장
s = set() # 중복되는 단어를 제거하기 위해 set을 사용한다.

#리스트에서 단어 찾기
for i in l:
    str="" # 문장에서 단어를 찾아 저장할 string변수
    for j in range(len(i)): # 각 요소의 길이만큼 반복
        if i[j] not in string.punctuation: # string.punctuation에 있는 글자가 아닐경우 str에 추가
            # string.punctuation: !"#$%&'()*+,-./:;<=>?@[\]^_`{|}~
            str+=i[j]
        else: #one,two,three와 같이 공백 없이 문장을 입력할 경우
            if(str!=""):
               s.add(str) #이전에 완성된 단어가 있으면 s에 추가하고 str를 초기화하여 계속 진행
            str=""
            continue
    if(str!=""):
        s.add(str) # 새로 생성한 단어를 s에 추가
print("단어의 개수:",len(s)) # 단어의 갯수 출력