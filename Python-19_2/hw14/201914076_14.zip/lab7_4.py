"""
입력하는 문장의 단어의 개수를 출력하시오. 대소문자 구별을 하지 않게 처리하라.
“'.,!?()/ 는 단어가 아니다.

입력예)
문장: While The Python Language Reference describes the exact syntax and semantics of the Python language,
this library reference manual describes the standard library that is distributed with Python.
It also describes some of the optional components that are commonly included in Python distributions.

출력예)
단어의 개수:

w=input("문장:") #문장 입력 받기

w=w.replace('"','') #“'.,!?()/와 함께 입력 받아도 단어를 확인할 수 있도록 변경시킨다.
w=w.replace("'","") #만약 replace를 하지 않으면 apple.을 단어로 치지 않기 때문에 .을 변경하도록 한다.
w=w.replace(",","") #replace("찾을값", "바꿀값", [바꿀횟수])
w=w.replace(".","")
w=w.replace("!","")
w=w.replace("?","")
w=w.replace("/","")
w=w.replace("(","")
w=w.replace(")","")
w=w.lower() #문장을 소문자로 바꿈
word=[] #리스트형 변수 word 생성

for words in w.split(" "): #w에 입력된 문장을 공백을 기준으로 나눔
    if words.isalpha(): #만약 words가 알파벳으로만 이루어졌다면
        word.append(words) #words를 word에 추가한다

word=list(set(word)) #중복된 값이 있던 list를 set 형태로 바꿔 중복된 값 삭제
print("단어의 개수:",len(word)) #단어의 개수 출력

a=input("문장:")
a=a.replace(",","")
a=a.replace(".","")
a=a.replace("!","")
a=a.replace("?","")
a=a.replace("/","")
a=a.replace("(","")
a=a.replace(")","")
a=a.lower()
word=[]

for words in a.split(sep=' '):
    for i in range(0,len(words)):
        if words.isalpha():
            word.append(words)

word=list(set(word))
print("단어의 개수:",len(word))
w=input("문장:") #문장 입력 받기
"""
w=input("문장:") #문장 입력 받기

w=w.replace('"','') #“'.,!?()/와 함께 입력 받아도 단어를 확인할 수 있도록 변경시킨다.
w=w.replace("'","") #만약 replace를 하지 않으면 apple.을 단어로 치지 않기 때문에 “'.,!?()/을 변경하도록 한다.
w=w.replace(",","") #replace("찾을값", "바꿀값", [바꿀횟수])
w=w.replace(".","")
w=w.replace("!","")
w=w.replace("?","")
w=w.replace("/","")
w=w.replace("(","")
w=w.replace(")","")
w=w.lower() #문장을 소문자로 바꿈
word=[] #리스트형 변수 word 생성

for words in w.split(" "): #w에 입력된 문장을 공백을 기준으로 나눔
    if words.isalpha(): #만약 words가 알파벳으로만 이루어졌다면
        word.append(words) #words를 word에 추가한다

word=list(set(word)) #중복된 값이 있던 list를 set 형태로 바꿔 중복된 값 삭제
print("단어의 개수:",len(word)) #단어의 개수 출력
