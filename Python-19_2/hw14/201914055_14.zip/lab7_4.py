"""
입력하는 문장의 단어의 개수를 출력하시오. 대소문자 구별을 하지 않게 처리하라.
“'.,!?()/ 는 단어가 아니다.

입력예)
문장: While The Python Language Reference describes the exact syntax and semantics of the Python language, this library reference manual describes the standard library that is distributed with Python. It also describes some of the optional components that are commonly included in Python distributions.

출력예)
단어의 개수:
"""
# 문장 입력
sentence = input("문장: ")

# 문장을 모두 소문자로 바꿔주기
s1 = sentence.lower()

# “'.,!?()/ 를 없애주기
s2 = s1.replace("\"", "").replace("\'", "").replace(".", "").replace(",", "").replace("!", "").replace("?", "").replace("(", "").replace(")", "").replace("/", "")

# set을 통해 중복 검사해주기
s3 = set(s2.split())

print("단어의 개수: ", len(s3))