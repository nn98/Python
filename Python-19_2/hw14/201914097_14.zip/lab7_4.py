#201914097 이가은
"""
입력받는 문자의 단어의 개수 출력
",',.,!,?,/ 등 특수문자는 단어가 아님
대소문자 구분하지 않음
"""
s=input("입력:").lower() #입력된 문장을 모두 소문자로 바꾼다
s = s.replace('"','')#replace("찾을값","바꿀값")
s = s.replace('/','') #replace를 이용하여 str에 쓰인 특수문자를 모두 없앤다
s = s.replace('.','')
s = s.replace("'","")
s = s.replace(',','')
s = s.replace('!','')
s = s.replace('?','')
s = s.replace('(','')
s = s.replace(')','')
s = s.replace('/','')

s=set(s.split()) #띄어쓰기로 구분하고 set에 넣어 중복된 것은 포함되지 않도록 한다

sum=0 #sum을 통해 단어의 개수를 셀 것이기 때문에 0으로 초기화한다

for i in s: #for문을 이용하여 sum에 추가
    if i.isalpha(): #알파벳으로 구성되어있으면
        sum+=1 #하나씩 증가시킨다

print("단어의 개수:",sum) #저장된 sum을 출력하여 단어의 개수를 출력한다