import re # 특수문자를 제거하는 정규표현식을 사용했습니다.

text = input("문장:") # 문장을 입력받습니다.

new_text = re.sub("[,?.'/!]", '', text).split() #re.sub을 이용해서 문장내에 있는 특수문자를 지워준후 split을 이용해서
#리스트 형식으로 만들어줍니다.

for i in range(len(new_text)): # for문과 lower를 이용해서 리스트에있는 대문자를 전부 소문자로 바꿔줍니다.
    new_text[i] = new_text[i].lower()

erase = set(new_text) #set을 이용해서 중복되는 단어를 지워줍니다.

print("단어의 개수:", len(erase)) # 중복되는 단어들을 지워준 후 단어가 몇개인지 출력합니다.
