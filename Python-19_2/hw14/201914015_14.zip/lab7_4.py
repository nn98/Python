"""
입력하는 문장의 단어의 개수를 출력하시오. 대소문자 구별을 하지 않게 처리하라.
“'.,!?()/ 는 단어가 아니다.

입력예)
문장: While The Python Language Reference describes the exact syntax and semantics of the Python language, this library reference manual describes the standard library that is distributed with Python. It also describes some of the optional components that are commonly included in Python distributions.

출력예)
단어의 개수:
"""

sentence=input("문장:").split() #sentence에 문장 입력 받기
a=0 #a는 0으로 초기화
for i in sentence: 
    sentence[a]=i.lower() #단어 소문자로 바꿔주는 함수 
    a=a+1
    for j in range(len(sentence)): #단어를 차례차례 반복시킴
        for m in sentence[j]: #각 알파벳을 차례차례 반복시킴
            if m in ('"',"'",'.',',','!','?','(',')','/'): #만약 알파벳 하나하나에 이런 특수문자가 포함된다면
                sentence[j]=sentence[j][0:len(sentence[j])-1] #해당단어를 특수문자 하나를 뺀것으로 바꾸기

sentence=set(sentence) #집합으로 만들어 중복되는 단어 제거해주기 
print("단어의 개수:%d"%len(sentence)) #문장 단어 갯수 출력 
