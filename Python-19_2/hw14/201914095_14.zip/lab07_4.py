'''
입력하는 문장의 단어의 개수를 출력하시오. 대소문자 구별하지 않게 처리하라.
`'".,!?()/는 단어가 아니다.
입력예)
문장 : While The Python Language Reference describes the exact syntax and semantics of the Python language, this library reference manual describes the standard library that is distributed with Python. It also describes some of the optional components that are commonly included in Python distributions.
'''
str = input("문장 : ").lower()    # 문장 입력 - 소문자로 입력받는다.
not_word = list(",.?!/'\"()")   # 단어가 아닌 것들
result =""      # 빈 문자열 선언
for i in str:       # 반복
    if i not in not_word:   # 단어인지 아닌지 판별
        result += i     # 단어가 맞으면 새로운 문자열로 복사

word = set(result.split())     # 띄어쓰기를 기준으로 단어를 set한다.
print("단어의 개수 : %d" %(len(word)))   # set의 개수가 단어의 개수 이다.
print(word)