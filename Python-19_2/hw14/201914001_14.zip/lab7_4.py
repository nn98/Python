'''
입력하는 문장의 단어의 개수를 출력하시오. 대소문자 구별을 하지 않게 처리하라.
“34 '39 .46 ,44 !33 ?63 (40 )41 /47 는 단어가 아니다.
입력예)
문장: While The Python Language Reference describes the exact syntax and semantics of the Python language, this library reference manual describes the standard library that is distributed with Python. It also describes some of the optional components that are commonly included in Python distributions.
출력예)
단어의 개수:
'''
def process(w): #함수 정의
    a = ""
    for i in w:
        if(i.isalpha()): #알파벳이면 저장
            a += i

    return a.lower() #소문자로 바꿔서 반환

words = set()

s = input("문장: ") #입력받기
line = s.split() #스페이스 단위로 분리하기

for word in line: #반복
    result = process(word) #함수호출된 단어를 result에 저장
    if (result):
        words.add(result) #결과값 words에 저장

print("단어의 개수: ", len(words)) #출력
