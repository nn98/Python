string = input("문장: ")  # 문장을 입력받음

if string == " ":  # 문장 자체가 공백일 때
    print(0)
else:  # 문장 자체가 공백이 아닐 경우
    words = string.split(" ")  # 띄어쓰기로 구분

    while '' in words:  # 문장 양쪽에 있는 공백이 없어질 때까지 반복
        words.remove('')  # 공백을 제거

print("단어의 개수:", len(words))  # 단어의 개수 출력
