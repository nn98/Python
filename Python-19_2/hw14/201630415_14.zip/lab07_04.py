"""
입력하는 문장의 단어의 개수를 출력
"".?!()/ 는 단어가 아니다.
입력 ex)
While The Python Language Reference describes the exact syntax and semantics of the Python language,
this library reference manual describes the standard library that is distributed with Python.
It also describes some of the optional components that are commonly included in Python distributions.
"""

a=input(" 문장 입력").split() #enter입력시까지 입력받음


count=0 #단어 개수


for _ in a:
    count+=1 #입력마다 개수 증가

print("단어의 개수:",count)