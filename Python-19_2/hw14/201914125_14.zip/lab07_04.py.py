"""
문제 : 입력하는 문장의 단어의 개수를 출력하시오. 대소문자 구별을 하지 않게 처리하라.
“'.,!?()/ 는 단어가 아니다.

입력예)
문장: While The Python Language Reference describes the exact syntax and semantics of the Python language,
this library reference manual describes the standard library that is distributed with Python.
It also describes some of the optional components that are commonly included in Python distributions.

 출력예)

단어의 개수:

작성자 : 오치현
작성일 : 2019.11.11
"""
def deleteSymbol (list) :
    """
    “'.,!?()/를 찾아 없애는 함수
    :param list: 문장 입력 sentence를 넘겨 받음
    :return: 특수문자가 사라진 단어들의 리스트를 리턴함 list
    """
    symbol = "\"\'.,!?()/"
    i = 0
    while (i != len(list)) :
        a = -1
        for j in range(len(symbol)) : # 특수문자를 하나하나 찾아보는 반복문
            a = list[i].find(symbol[j]) # 해당하는 특수문자가 단어에 없으면 a에는 -1을 저장
            if (a != -1) : # a가 -1이 아닐시에 재배치를 통해 문자를 삭제
                list[i] = list[i].replace(symbol[j], "")
                a = 0
                break
        if (a == 0) :
            continue

        i += 1

    return list # 특수문자가 삭제된 리스트를 반환

def changeLower (list) :
    """
    모든 문자를 소문자로 변환하는 함수
    :param list: 특수문자가 사라진 리스트를 받음 list
    :return: 소문자로 변환된 단어를 전달받은 temp 리스트 반환 temp
    """
    temp = [] # 리스트 레퍼런스 변수 재배치
    for i in range(len(list)) : # 소문자로 변환된 단어를 temp리스트에 하나하나 저장함
        temp.append(list[i].lower())

    return temp

def countWord (list) :
    """
    set 함수를 통해 중복되는 단어를 삭제, 글자 수 반환하는 함수
    :param list: 특수문자 삭제, 소문자로 변환된 리스트를 받음 list
    :return: 단어의 개수를 반환 len(set(list))
    """
    return len(set(list))

sentence = input().split() # 문장 입력
pureWords = changeLower(deleteSymbol(sentence))# 중복되지 아니하며 특수문자가 없고 모두 소문자인 단어들의 집합을 포함하는 리스트

print("단어의 개수:", countWord(pureWords)) # 단어의 개수를 countWord함수를 통해 출력