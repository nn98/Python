'''
입력하는 문장의 단어의 개수를 출력하시오. 대소문자 구별을 하지 않게 처리하라.
“'.,!?()/ 는 단어가 아니다.
입력예)
문장: While The Python Language Reference describes the exact syntax
and semantics of the Python language, this library reference manual describes
the standard library that is distributed with Python. It also describes
 some of the optional components that are commonly included in Python distributions.
출력예)
단어의 개수:
'''
a=list(input("문장:")) #a로 문장 입력 만들기
b="" #합치기 위한 것 만듬
r=['.',',','?','!','"','\''] #단어가 아닌 것들

for c in range(len(a)):  #대문자를 모두 소문자로 바꿈
    if ord(a[c]) <= 90 and ord(a[c]) >= 65:
        a[c] = chr(ord(a[c]) + 32)

for c in range(len(r)):  #특수문자 없애는 작업
    while r[c] in a:
        a.remove(r[c])

for c in range(len(a)): #합침
    b+=a[c]

w=set(b.split())#중복되는 단어들을 하나로

print("단어의 갯수:",len(w))#단어의 갯수 출력하기
'''
어려웠던 점: 먼저 파이썬과 c프로그래밍이 자꾸 헷갈리며
대문자와 소문자 구별법과 단어가 아닌 특수문자를 어떻게 처리할지 
생각 하기 힘들어서 오래 걸린 것 같다..
'''