str="While The Python Language Reference describes the exact syntax and semantics of the Python language, this library reference manual describes the standard library that is distributed with Python. It also describes some of the optional components that are commonly included in Python distributions."
words = str.split(" ")  # 띄어쓰기로 나누기

while '' in words:  # 문장 양쪽에 있는 공백이 없어질 때까지 반복
    words.remove('')
while '?' in words:
    words.remove('?')
while '.' in words:
    words.remove('.')
while ',' in words:
    words.remove('.')
while '/' in words:
    words.remove('.')

print(words)
print("단어의 개수:", len(words))