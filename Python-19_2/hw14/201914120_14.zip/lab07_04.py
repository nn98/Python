"""
입력하는 문자의 단어의 개수를 출력하시오. 대소문자 구별을 하지 않게 처리하라.
"'.,!?()/는 단어가 아니다.
과제번호: 14
작성자: 이 승 헌
목적: Python 과제
작성일: 2019/11/11
"""
sentence=input().split() #문장입력받기
k=0 #sentence의 인덱스값
for i in sentence:  #sentence의 단어들을 소문자로 변경
    sentence[k]=i.lower()
    k += 1
for j in range(len(sentence)):  #sentence의 단어들중에 특수문자랑
    for q in sentence[j]:       #붙어있는 단어에서 특수문자 제거
        if q in ("'",'"',",",".","!","?","(",")","/"):
            sentence[j]=sentence[j][0:len(sentence[j])-1]
sentence=set(sentence)  #sentence의 중복제거
print(len(sentence)) #단어 개수 출력