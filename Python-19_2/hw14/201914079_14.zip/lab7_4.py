"""
(lab7_4)

입력하는 문장의 단어의 개수를 출력하시오. 대소문자 구별을 하지 않게 처리하라.
“'.,!?()/ 는 단어가 아니다.

입력예)
문장: While The Python Language Reference describes the exact syntax and semantics of the Python language, this library reference manual describes the standard library that is distributed with Python. It also describes some of the optional components that are commonly included in Python distributions.

 출력예)

단어의 개수:

만든날짜 : 2019. 11. 12
만든이 : 유혜지
"""

def conversion(w): #알파벳인 경우, 소문자로 만드는 함수(구두점 제외)
    output =""
    for ch in w:
        if(ch.isalpha()): # 만약에 알파벳이면('.,!?()/와 같은 문자를 제외)
            output += ch #ch를 계속해서 output에 저장한다
    return output.lower () #소문자로 변환한다.
words = set() #공백 세트 생성

sentence = input("문장 : ").split() #문장을 단어로 쪼개서 받는다

for line in sentence: # 파일의 모든 줄에 반복
    for word in sentence : # 문장에 있는 단어들에 대해서
        words.add(conversion(word)) # 단어를 세트에 추가한다.

print("단어의 개수 : ",len(words)) #단어의 개수를 출력한다.