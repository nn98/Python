max=0 #max값
result=0 #결과값

for i in range(1,10000): # for문으로 범위 지정
    if(max<i):
        max=i
    result+=i


print("최대값:{0}".format(max)) # 최대값을 출력
print("n의 값:{0}".format(result)) # n의 값을 출력

'''
C프로그래밍 때 반복문을 복습을 안해서 반복문 쓰는데 어떤곳에서 어떻게 써야할 지 고민이 있었다.
'''